package com.taller.seccion1;

public class Ejercicio1 {
    public static void main(String[] args) {
        int numero = 10;
        double decimal = 5.5;
        char letra = 'A';
        String texto = "Hola Mundo";
        boolean estado = true;

        System.out.println("int: " + numero);
        System.out.println("double: " + decimal);
        System.out.println("char: " + letra);
        System.out.println("String: " + texto);
        System.out.println("boolean: " + estado);
    }
}
