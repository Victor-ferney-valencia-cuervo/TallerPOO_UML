package com.taller.seccion1;

public class Ejercicio10 {
    public static void main(String[] args) {
        double base = 4;
        double exponente = 2;
        double potencia = Math.pow(base, exponente);
        double raiz = Math.sqrt(base);
        System.out.println("Potencia: " + potencia);
        System.out.println("Raíz cuadrada: " + raiz);
    }
}
