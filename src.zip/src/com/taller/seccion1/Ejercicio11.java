package com.taller.seccion1;

public class Ejercicio11 {
    public static void main(String[] args) {
        double aleatorio = Math.random();
        System.out.println("Número aleatorio: " + aleatorio);
    }
}
