package com.taller.seccion1;

public class Ejercicio12 {
    public static void main(String[] args) {
        double precio = 1234.56789;
        System.out.printf("Precio: %.2f\n", precio);
    }
}
