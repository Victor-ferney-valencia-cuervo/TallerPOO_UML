package com.taller.seccion1;

public class Ejercicio14 {
    public static void main(String[] args) {
        String texto = "";
        System.out.println("¿Está vacío?: " + texto.isEmpty());
    }
}
