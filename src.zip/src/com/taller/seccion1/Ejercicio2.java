
package com.taller.seccion1;

public class Ejercicio2 {
    public static void main(String[] args) {
        int a = 8, b = 3;
        System.out.println("Suma: " + (a + b));
        System.out.println("Resta: " + (a - b));
        System.out.println("Multiplicación: " + (a * b));
        System.out.println("División: " + (a / b));
        System.out.println("Módulo: " + (a % b));
    }
}
