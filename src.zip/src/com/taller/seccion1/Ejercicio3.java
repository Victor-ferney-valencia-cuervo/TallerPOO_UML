package com.taller.seccion1;

public class Ejercicio3 {
    public static void main(String[] args) {
        int x = 5, y = 10;
        System.out.println("x < y: " + (x < y));
        System.out.println("x > y: " + (x > y));
        System.out.println("x == y: " + (x == y));
        System.out.println("x != y: " + (x != y));

        boolean a = true, b = false;
        System.out.println("a && b: " + (a && b));
        System.out.println("a || b: " + (a || b));
        System.out.println("!a: " + (!a));
    }
}
