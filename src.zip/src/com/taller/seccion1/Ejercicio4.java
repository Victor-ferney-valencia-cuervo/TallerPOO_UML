package com.taller.seccion1;

public class Ejercicio4 {
    public static void main(String[] args) {
        // Esto es un comentario de línea

        /*
         * Esto es un comentario de bloque.
         * Sirve para explicar secciones más grandes de código.
         */
        int valor = 10;
        System.out.println("Valor: " + valor); // Imprime el valor
    }
}
