package com.taller.seccion1;

public class Ejercicio5 {
    public static void main(String[] args) {
        int numero = 42; // Variable entera
        System.out.println("El número es: " + numero); // Comentario en línea xd
    }
}
