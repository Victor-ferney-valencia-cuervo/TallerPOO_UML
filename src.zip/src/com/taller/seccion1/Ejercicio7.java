package com.taller.seccion1;

public class Ejercicio7 {
    public static void main(String[] args) {
        String numeroTexto = "123";
        int numero = Integer.parseInt(numeroTexto);
        double decimal = Double.parseDouble(numeroTexto);
        String numeroComoTexto = Integer.toString(numero);
        System.out.println("int: " + numero + ", double: " + decimal + ", texto: " + numeroComoTexto);
    }
}
