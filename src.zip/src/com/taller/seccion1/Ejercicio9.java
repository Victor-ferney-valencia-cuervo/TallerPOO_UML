package com.taller.seccion1;

public class Ejercicio9 {
    public static void main(String[] args) {
        final double PI = 3.14159;
        System.out.println("Valor de PI: " + PI);
    }
}
