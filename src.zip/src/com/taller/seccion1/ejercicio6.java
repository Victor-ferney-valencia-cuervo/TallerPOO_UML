package com.taller.seccion1;

import java.util.Scanner;

public class Ejercicio6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingresa un número entero: ");
        int numero = sc.nextInt();
        System.out.print("Ingresa un número decimal: ");
        double decimal = sc.nextDouble();
        System.out.println("Entero: " + numero + ", Decimal: " + decimal);
        sc.close();
    }
}
