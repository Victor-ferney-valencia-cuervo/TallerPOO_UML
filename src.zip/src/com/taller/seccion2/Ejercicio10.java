package com.taller.seccion2;

public class Ejercicio10 {
    public static int fibonacci(int n) {
        if (n <= 1) return n;
        return fibonacci(n - 1) + fibonacci(n - 2);
    }

    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            System.out.println("Fibonacci " + i + ": " + fibonacci(i));
        }
    }
}