package com.taller.seccion2;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio11 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Integer> numeros = new ArrayList<>();
        System.out.println("Ingresa 5 números:");
        for (int i = 0; i < 5; i++) {
            numeros.add(sc.nextInt());
        }

        System.out.println("Números pares:");
        for (int n : numeros) {
            if (n % 2 == 0) System.out.println(n);
        }
        sc.close();
    }
}