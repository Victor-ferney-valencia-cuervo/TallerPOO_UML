package com.taller.seccion2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Ejercicio12 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Integer> lista = new ArrayList<>();
        System.out.println("Ingresa 5 números:");
        for (int i = 0; i < 5; i++) {
            lista.add(sc.nextInt());
        }

        Collections.sort(lista);
        System.out.println("Lista ordenada: " + lista);
        sc.close();
    }
}