package com.taller.seccion2;

public class Ejercicio2 {
    public static void main(String[] args) {
        int edad = 30;
        if (edad < 12) {
            System.out.println("Niño");
        } else if (edad < 18) {
            System.out.println("Adolescente");
        } else if (edad < 60) {
            System.out.println("Adulto");
        } else {
            System.out.println("Anciano");
        }
    }
}