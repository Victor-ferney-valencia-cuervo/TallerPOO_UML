package com.taller.seccion2;

import java.util.Scanner;

public class Ejercicio5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int suma = 0, num;
        while (true) {
            System.out.print("Ingresa un número (0 para terminar): ");
            num = sc.nextInt();
            if (num == 0) break;
            suma += num;
        }
        System.out.println("Suma total: " + suma);
        sc.close();
    }
}