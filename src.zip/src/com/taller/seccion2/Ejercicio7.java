package com.taller.seccion2;

public class Ejercicio7 {
    public static void main(String[] args) {
        for (int i = 1; i <= 10; i++) {
            if (i == 5) continue;
            if (i == 9) break;
            System.out.println("Número: " + i);
        }
    }
}