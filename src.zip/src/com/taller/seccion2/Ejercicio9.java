package com.taller.seccion2;

public class Ejercicio9 {
    public static void main(String[] args) {
        String[] nombres = {"Ana", "Luis", "Carlos"};
        for (String nombre : nombres) {
            System.out.println("Hola, " + nombre);
        }
    }
}
