# Respuestas - Sección 2
**ejercicio15:**
-if,else:se usan cuando se nesesita evaluar una o varias condiciones booleanas que no depende de un solo valor.

switch:cuando se evaluan una sola constante con multiples valores constante