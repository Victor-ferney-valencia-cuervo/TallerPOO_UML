package com.taller.seccion3;

public class Ejercicio3 {
    public static void main(String[] args) {
        int[] numeros = {1, 2, 3, 4, 5};

        System.out.println("Con índice:");
        for (int i = 0; i < numeros.length; i++) {
            System.out.println(numeros[i]);
        }

        System.out.println("Con for-each:");
        for (int n : numeros) {
            System.out.println(n);
        }
    }
}
