package com.taller.seccion3;

import java.util.ArrayList;

public class Ejercicio4 {
    public static void main(String[] args) {
        ArrayList<Integer> lista = new ArrayList<>();
        lista.add(10);
        lista.add(20);
        lista.add(30);

        lista.remove(Integer.valueOf(20));

        for (int numero : lista) {
            System.out.println(numero);
        }
    }
}
