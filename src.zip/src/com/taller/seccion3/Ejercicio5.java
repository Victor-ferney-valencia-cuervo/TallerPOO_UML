package com.taller.seccion3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Ejercicio5 {
    public static void main(String[] args) {
        String[] array = {"a", "b", "c"};
        List<String> lista = new ArrayList<>(Arrays.asList(array));

        String[] nuevoArray = lista.toArray(new String[0]);

        System.out.println("Lista: " + lista);
        System.out.println("Array: " + Arrays.toString(nuevoArray));
    }
}
