package com.taller.seccion3;

import java.util.ArrayList;
import java.util.LinkedList;

public class Ejercicio6 {
    public static void main(String[] args) {
        ArrayList<String> arrayList = new ArrayList<>();
        LinkedList<String> linkedList = new LinkedList<>();

        arrayList.add("A");
        linkedList.add("A");

        arrayList.add("B");
        linkedList.add("B");

        System.out.println("ArrayList: " + arrayList);
        System.out.println("LinkedList: " + linkedList);
    }
}
