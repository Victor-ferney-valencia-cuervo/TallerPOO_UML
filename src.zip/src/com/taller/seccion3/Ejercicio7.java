package com.taller.seccion3;

import java.util.HashSet;

public class Ejercicio7 {
    public static void main(String[] args) {
        HashSet<Double> conjunto = new HashSet<>();
        conjunto.add(1.1);
        conjunto.add(2.2);
        conjunto.add(1.1); // duplicado

        System.out.println("Conjunto: " + conjunto);
        System.out.println("Tamaño: " + conjunto.size());
    }
}
