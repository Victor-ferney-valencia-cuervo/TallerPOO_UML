package com.taller.seccion4;

public class Persona {
    private String nombre;
    private int edad;
}
