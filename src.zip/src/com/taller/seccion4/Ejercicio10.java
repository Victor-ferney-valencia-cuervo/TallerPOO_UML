/**
 * Clase que representa una persona con nombre y edad.
 * @author victor 
 */
public class Persona {
    // ...
}
private Direccion direccion;

public void setDireccion(Direccion direccion) {
    this.direccion = direccion;
}

public Direccion getDireccion() {
    return direccion;
}
