public final void metodoFinal() {
    System.out.println("Este método no se puede sobrescribir.");
}
