@Override
public Persona clone() {
    try {
        return (Persona) super.clone();
    } catch (CloneNotSupportedException e) {
        return null;
    }
}
