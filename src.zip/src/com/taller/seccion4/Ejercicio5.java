c

public class MainPersona {
    public static void main(String[] args) {
        Persona p1 = new Persona();
        Persona p2 = new Persona("Ana", 20);
        Persona p3 = new Persona("Luis", 30);

        p1.presentarse();
        p2.presentarse();
        p3.presentarse();
    }
}
