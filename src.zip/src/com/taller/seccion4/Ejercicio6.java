


public void setNombre(String nombre) {
    this.nombre = nombre;
}

