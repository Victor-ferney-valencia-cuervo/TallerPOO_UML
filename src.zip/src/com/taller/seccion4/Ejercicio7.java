
public class Ejercicio7 {

}
private static int contador = 0;

public Persona() {
    contador++;
}

public Persona(String nombre, int edad) {
    this.nombre = nombre;
    this.edad = edad;
    contador++;
}

public static int getContador() {
    return contador;
}
