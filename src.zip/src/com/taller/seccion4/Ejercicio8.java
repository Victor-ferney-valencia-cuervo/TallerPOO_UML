

@Override
public String toString() {
    return "Persona[nombre=" + nombre + ", edad=" + edad + "]";
}
