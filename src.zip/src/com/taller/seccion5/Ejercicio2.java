
public class Ejercicio2 {

}
