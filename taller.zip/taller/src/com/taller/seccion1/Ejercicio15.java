package com.taller.seccion1;

public class Ejercicio15 {
    public static void main(String[] args) {
        System.out.println("Ejercicio 15 ejecutado.");
    }
}