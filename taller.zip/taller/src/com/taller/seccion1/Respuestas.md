# Respuestas - Sección 1

**Ejercicio 15:**  
- Los tipos primitivos (`int`, `double`, etc.) son simples, rápidos, y almacenan directamente el valor.  
- Los objetos (`String`, `Integer`, etc.) son instancias de clases, ofrecen métodos útiles, pero consumen más memoria.
