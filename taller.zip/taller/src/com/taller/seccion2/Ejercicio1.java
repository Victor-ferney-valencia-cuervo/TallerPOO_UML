package com.taller.seccion2;

public class Ejercicio1 {
    public static void main(String[] args) {
        int x = 10;
        if (x > 5) {
            System.out.println("x es mayor que 5");
        } else {
            System.out.println("x es menor o igual a 5");
        }
    }
}