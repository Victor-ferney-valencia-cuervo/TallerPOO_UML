package com.taller.seccion2;

import java.util.HashSet;
import java.util.Scanner;

public class Ejercicio13 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        HashSet<Integer> numeros = new HashSet<>();
        System.out.println("Ingresa números (5):");
        for (int i = 0; i < 5; i++) {
            numeros.add(sc.nextInt());
        }

        System.out.println("Conjunto sin duplicados: " + numeros);
        sc.close();
    }
}