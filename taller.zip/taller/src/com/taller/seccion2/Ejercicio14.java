
package com.taller.seccion2;

import java.util.Arrays;
import java.util.List;

public class Ejercicio14 {
    public static void main(String[] args) {
        String[] array = {"uno", "dos", "tres"};
        List<String> lista = Arrays.asList(array);
        System.out.println("Lista: " + lista);
    }
}