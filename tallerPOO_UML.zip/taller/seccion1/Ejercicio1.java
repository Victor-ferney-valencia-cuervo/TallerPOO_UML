package com.taller.seccion1;

public class Ejercicio1 {
    public static void main(String[] args) {
        int numero = 25;
        double altura = 1.75;
        char inicial = 'C';
        String nombre = "Carlos";
        boolean esEstudiante = true;

        System.out.println(numero);
        System.out.println(altura);
        System.out.println(inicial);
        System.out.println(nombre);
        System.out.println(esEstudiante);
    }
}
