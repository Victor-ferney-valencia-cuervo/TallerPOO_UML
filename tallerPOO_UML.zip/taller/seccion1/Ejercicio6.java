package com.taller.seccion1;

public class Ejercicio6 {
    public static void main(String[] args) {
        System.out.println("Ejercicio 6 ejecutado.");
    }
}