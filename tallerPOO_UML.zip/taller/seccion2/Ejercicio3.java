package com.taller.seccion2;

import java.util.Scanner;

public class Ejercicio3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("1. Opción A\n2. Opción B\n3. Opción C");
        int opcion = sc.nextInt();

        switch (opcion) {
            case 1 -> System.out.println("Elegiste A");
            case 2 -> System.out.println("Elegiste B");
            case 3 -> System.out.println("Elegiste C");
            default -> System.out.println("Opción inválida");
        }

        sc.close();
    }
}