package com.taller.seccion2;

import java.util.Scanner;

public class Ejercicio6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String contraseña;
        do {
            System.out.print("Introduce la contraseña: ");
            contraseña = sc.nextLine();
        } while (!contraseña.equals("1234"));
        System.out.println("Contraseña correcta");
        sc.close();
    }
}